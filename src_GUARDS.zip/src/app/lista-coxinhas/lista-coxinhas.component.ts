import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-coxinhas',
  templateUrl: './lista-coxinhas.component.html',
  styleUrls: ['./lista-coxinhas.component.sass']
})
export class ListaCoxinhasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
