import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coxinha-info',
  templateUrl: './coxinha-info.component.html',
  styleUrls: ['./coxinha-info.component.sass']
})
export class CoxinhaInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
