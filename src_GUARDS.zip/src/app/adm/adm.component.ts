import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adm',
  templateUrl: './adm.component.html',
  styleUrls: ['./adm.component.sass']
})
export class AdmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
